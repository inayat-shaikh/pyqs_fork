This is the backup of all the previous things
